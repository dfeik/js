	/*导航*/
    // slideToggle() 方法通过使用滑动效果（高度变化）来切换元素的可见状态。
    //如果被选元素是可见的，则隐藏这些元素，如果被选元素是隐藏的，则显示这些元素。
	$(function(){
		$(".wp-menu li").hover(function() {
			$(this).siblings().find('.sub-menu').stop().slideUp(150)
			$(this).children('.sub-menu').stop().slideDown(200);
			$(this).addClass('hover');
		}, function() {
			$(this).children('.sub-menu').stop().slideUp(150);
			$(this).removeClass('hover');
		});
		
		$(".wp-menu li").each(function(){
			$(this).children(".menu-switch-arrow").appendTo($(this).children(".menu-link"));
		});
	});
	